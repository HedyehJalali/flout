Hello,

Thank for downloading CERVANTTIS.

NOTE: This font is FREE 100% FOR COMMERCIAL USE! But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/RianRahardi

Please visit our store for more great fonts : 
https://creativemarket.com/creatype?u=misterryart

And follow our instagram for update : @creatypestudio


How to Enable OpenType Features in Word, Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

Thanks,


Creatype Studio